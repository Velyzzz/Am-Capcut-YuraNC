package com.am2cc.converter

import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var tvShizukuStatus: TextView
    private lateinit var btnConnectShizuku: Button
    private lateinit var tvXmlInfo: TextView
    private lateinit var btnPickXml: Button
    private lateinit var btnRefreshDrafts: TextView
    private lateinit var spinnerDrafts: Spinner
    private lateinit var switchBakeJj: SwitchCompat
    private lateinit var btnInjectDirect: Button
    private lateinit var btnBackupMode: Button
    private lateinit var tvLog: TextView

    private var parsedXml: AlightMotionConverter.ParsedXml? = null
    private val draftFolders = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvShizukuStatus = findViewById(R.id.tvShizukuStatus)
        btnConnectShizuku = findViewById(R.id.btnConnectShizuku)
        tvXmlInfo = findViewById(R.id.tvXmlInfo)
        btnPickXml = findViewById(R.id.btnPickXml)
        btnRefreshDrafts = findViewById(R.id.btnRefreshDrafts)
        spinnerDrafts = findViewById(R.id.spinnerDrafts)
        switchBakeJj = findViewById(R.id.switchBakeJj)
        btnInjectDirect = findViewById(R.id.btnInjectDirect)
        btnBackupMode = findViewById(R.id.btnBackupMode)
        tvLog = findViewById(R.id.tvLog)

        btnConnectShizuku.setOnClickListener { requestShizuku() }
        btnPickXml.setOnClickListener { registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) loadXml(uri) }.launch(arrayOf("*/*")) }
        btnRefreshDrafts.setOnClickListener { refreshDrafts() }
        btnInjectDirect.setOnClickListener { inject() }
        btnBackupMode.setOnClickListener {
            if (parsedXml == null) { log("Pilih XML dulu!"); return@setOnClickListener }
            registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) backupJson(uri) }.launch(arrayOf("application/json", "*/*"))
        }
        checkShizuku()
    }

    private fun requestShizuku() {
        try {
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) checkShizuku()
            else Shizuku.requestPermission(1001)
        } catch (e: Throwable) { tvShizukuStatus.text = "Error Shizuku: ${e.message}" }
    }

    private fun checkShizuku() {
        try {
            if (!ShizukuShell.isReady()) { tvShizukuStatus.text = "Shizuku belum aktif!"; return }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) { tvShizukuStatus.text = "Shizuku perlu izin!"; return }
            tvShizukuStatus.text = "Shizuku Terhubung (aShell aktif)"
            refreshDrafts()
        } catch (e: Throwable) { tvShizukuStatus.text = "Error: ${e.message}" }
    }

    private fun refreshDrafts() {
        lifecycleScope.launch {
            val (_, folders) = withContext(Dispatchers.IO) { ShizukuShell.listDraftProjects() }
            draftFolders.clear()
            draftFolders.addAll(folders)
            if (folders.isNotEmpty()) {
                spinnerDrafts.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, draftFolders)
                log("Ditemukan ${folders.size} draft CapCut.")
            } else { log("Draft CapCut kosong / tidak terbaca.") }
        }
    }

    private fun loadXml(uri: Uri) {
        lifecycleScope.launch {
            try {
                val parsed = withContext(Dispatchers.IO) { contentResolver.openInputStream(uri)?.use { AlightMotionConverter.parseXml(it) } }
                if (parsed != null) {
                    parsedXml = parsed
                    tvXmlInfo.text = "XML: ${parsed.title} (${parsed.clips.size} klip)"
                    log("XML berhasil dimuat.")
                }
            } catch (e: Throwable) { log("Error XML: ${e.message}") }
        }
    }

    private fun inject() {
        val xml = parsedXml ?: run { log("Pilih XML dulu!"); return }
        val folder = spinnerDrafts.selectedItem?.toString() ?: run { log("Pilih draft dulu!"); return }
        lifecycleScope.launch {
            val cacheIn = File(cacheDir, "in.json")
            val pull = withContext(Dispatchers.IO) { ShizukuShell.pullDraftToCache(folder, cacheIn) }
            if (pull.code != 0) { log("Gagal tarik draft: ${pull.stderr}"); return@launch }

            val converted = withContext(Dispatchers.Default) { AlightMotionConverter.injectIntoCapCutJson(cacheIn.readText(), xml, switchBakeJj.isChecked) }
            val cacheOut = File(cacheDir, "out.json")
            withContext(Dispatchers.IO) { cacheOut.writeText(converted) }

            val push = withContext(Dispatchers.IO) { ShizukuShell.pushDraftAndRestartCapCut(cacheOut, folder) }
            if (push.code == 0) log("BERHASIL! Buka CapCut sekarang.") else log("Gagal dorong draft: ${push.stderr}")
        }
    }

    private fun backupJson(uri: Uri) {
        val xml = parsedXml ?: return
        lifecycleScope.launch {
            val raw = withContext(Dispatchers.IO) { contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: "" }
            val converted = withContext(Dispatchers.Default) { AlightMotionConverter.injectIntoCapCutJson(raw, xml, switchBakeJj.isChecked) }
            val out = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "AM2CapCut").apply { mkdirs() }
            val file = File(out, "${xml.title}_draft.json")
            withContext(Dispatchers.IO) { file.writeText(converted) }
            log("Tersimpan di Download/AM2CapCut/")
        }
    }

    private fun log(msg: String) { tvLog.text = msg }
}
