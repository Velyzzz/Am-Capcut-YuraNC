package com.am2cc.converter

import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var tvShizukuStatus: TextView
    private lateinit var btnConnectShizuku: Button
    private lateinit var tvXmlInfo: TextView
    private lateinit var btnPickXml: Button
    private lateinit var btnRefreshDrafts: TextView
    private lateinit var spinnerDrafts: Spinner
    private lateinit var switchBakeJj: SwitchCompat
    private lateinit var btnInjectDirect: Button
    private lateinit var btnBackupMode: Button
    private lateinit var tvLog: TextView

    private var parsedXml: AlightMotionConverter.ParsedXml? = null
    private val draftFolders = mutableListOf<String>()

    private val binderListener = Shizuku.OnBinderReceivedListener {
        runOnUiThread { checkShizukuAndLoadDrafts() }
    }

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == 1001) {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                log("Izin Shizuku (aShell engine) diberikan!")
                checkShizukuAndLoadDrafts()
            } else {
                tvShizukuStatus.text = "● Izin Shizuku ditolak oleh pengguna."
                log("Gagal: Izin Shizuku ditolak.")
            }
        }
    }

    private val pickXmlLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) loadXmlFile(uri)
    }

    private val pickBackupJsonLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) processBackupJsonFile(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvShizukuStatus = findViewById(R.id.tvShizukuStatus)
        btnConnectShizuku = findViewById(R.id.btnConnectShizuku)
        tvXmlInfo = findViewById(R.id.tvXmlInfo)
        btnPickXml = findViewById(R.id.btnPickXml)
        btnRefreshDrafts = findViewById(R.id.btnRefreshDrafts)
        spinnerDrafts = findViewById(R.id.spinnerDrafts)
        switchBakeJj = findViewById(R.id.switchBakeJj)
        btnInjectDirect = findViewById(R.id.btnInjectDirect)
        btnBackupMode = findViewById(R.id.btnBackupMode)
        tvLog = findViewById(R.id.tvLog)

        try {
            Shizuku.addBinderReceivedListenerSticky(binderListener)
            Shizuku.addRequestPermissionResultListener(permissionListener)
        } catch (t: Throwable) {
            tvShizukuStatus.text = "● Error init Shizuku: ${t.message}"
        }

        btnConnectShizuku.setOnClickListener { requestShizukuConnection() }
        btnPickXml.setOnClickListener { pickXmlLauncher.launch(arrayOf("*/*")) }
        btnRefreshDrafts.setOnClickListener { refreshCapCutDraftList() }
        btnInjectDirect.setOnClickListener { injectViaIntegratedShell() }
        btnBackupMode.setOnClickListener {
            if (parsedXml == null) {
                log("Pilih file Preset .XML Alight Motion terlebih dahulu!")
                return@setOnClickListener
            }
            pickBackupJsonLauncher.launch(arrayOf("application/json", "*/*"))
        }

        checkShizukuAndLoadDrafts()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            Shizuku.removeBinderReceivedListener(binderListener)
            Shizuku.removeRequestPermissionResultListener(permissionListener)
        } catch (_: Throwable) {
        }
    }

    private fun requestShizukuConnection() {
        try {
            if (!ShizukuShell.isReady()) {
                tvShizukuStatus.text = "● Shizuku belum berjalan. Buka aplikasi Shizuku lalu tekan Start."
                log("Shizuku binder tidak aktif. Pastikan layanan Shizuku running.")
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                checkShizukuAndLoadDrafts()
            } else {
                Shizuku.requestPermission(1001)
            }
        } catch (t: Throwable) {
            tvShizukuStatus.text = "● Gagal koneksi Shizuku: ${t.message}"
            log("Exception Shizuku: ${t.message}")
        }
    }

    private fun checkShizukuAndLoadDrafts() {
        try {
            if (!ShizukuShell.isReady()) {
                tvShizukuStatus.text = "● Belum terhubung: Layanan Shizuku belum aktif."
                return
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                tvShizukuStatus.text = "● Shizuku aktif, ketuk tombol di bawah untuk memberi izin."
                return
            }
            tvShizukuStatus.text = "● Terhubung (Shizuku + aShell Engine uid=2000 aktif)"
            refreshCapCutDraftList()
        } catch (t: Throwable) {
            tvShizukuStatus.text = "● Error status Shizuku: ${t.message}"
        }
    }

    private fun refreshCapCutDraftList() {
        if (!ShizukuShell.isReady()) {
            log("Hubungkan Shizuku terlebih dahulu sebelum Refresh draft.")
            return
        }
        lifecycleScope.launch {
            log("Memindai folder draft CapCut via aShell engine...")
            val (status, folders) = withContext(Dispatchers.IO) {
                ShizukuShell.listDraftProjects()
            }
            draftFolders.clear()
            if (folders.isNotEmpty()) {
                draftFolders.addAll(folders)
                val adapter = ArrayAdapter(
                    this@MainActivity,
                    android.R.layout.simple_spinner_dropdown_item,
                    draftFolders
                )
                spinnerDrafts.adapter = adapter
                log("Ditemukan ${folders.size} proyek CapCut (terbaru: ${folders.first()}).")
            } else {
                spinnerDrafts.adapter = null
                log("Folder proyek CapCut kosong atau tidak terbaca: $status")
            }
        }
    }

    private fun loadXmlFile(uri: Uri) {
        lifecycleScope.launch {
            try {
                val parsed = withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)?.use { stream ->
                        AlightMotionConverter.parseXml(stream)
                    } ?: throw IllegalStateException("Gagal membuka file XML.")
                }
                parsedXml = parsed
                tvXmlInfo.text = "Proyek: ${parsed.title}\n" +
                    "Resolusi: ${parsed.width}x${parsed.height} @ ${parsed.fps}fps\n" +
                    "Total Potongan Klip: ${parsed.clips.size} klip • Efek JJ: ${parsed.totalJjEffects}"
                log("XML '${parsed.title}' berhasil dimuat (${parsed.clips.size} klip).")
            } catch (t: Throwable) {
                log("Gagal membaca XML: ${t.message}")
            }
        }
    }

    private fun injectViaIntegratedShell() {
        val xml = parsedXml
        if (xml == null) {
            log("Pilih file Preset .XML Alight Motion terlebih dahulu!")
            return
        }
        val selectedFolder = spinnerDrafts.selectedItem?.toString()
        if (selectedFolder.isNullOrBlank()) {
            log("Pilih proyek target CapCut terlebih dahulu (tekan Refresh jika kosong).")
            return
        }

        lifecycleScope.launch {
            try {
                log("1/3 Menarik draft CapCut '$selectedFolder' via aShell engine...")
                val cacheIn = File(cacheDir, "draft_in.json")
                val pullRes = withContext(Dispatchers.IO) {
                    ShizukuShell.pullDraftToCache(selectedFolder, cacheIn)
                }
                if (pullRes.code != 0 || !cacheIn.exists()) {
                    log("Gagal menarik file draft: ${pullRes.stderr}")
                    return@launch
                }

                log("2/3 Mengonversi ${xml.clips.size} klip XML ke JSON CapCut...")
                val rawJson = withContext(Dispatchers.IO) { cacheIn.readText() }
                val convertedJson = withContext(Dispatchers.Default) {
                    AlightMotionConverter.injectIntoCapCutJson(rawJson, xml, switchBakeJj.isChecked)
                }

                val cacheOut = File(cacheDir, "draft_out.json")
                withContext(Dispatchers.IO) { cacheOut.writeText(convertedJson) }

                log("3/3 Menimpa draft CapCut & memuat ulang aplikasi CapCut...")
                val pushRes = withContext(Dispatchers.IO) {
                    ShizukuShell.pushDraftAndRestartCapCut(cacheOut, selectedFolder)
                }
                if (pushRes.code == 0) {
                    log("BERHASIL! ${xml.clips.size} klip JJ disuntikkan ke '$selectedFolder'. Buka CapCut sekarang!")
                } else {
                    log("Gagal menimpa draft: ${pushRes.stderr}")
                }
            } catch (t: Throwable) {
                log("Gagal: ${t.message}")
            }
        }
    }

    private fun processBackupJsonFile(uri: Uri) {
        val xml = parsedXml ?: return
        lifecycleScope.launch {
            try {
                val rawJson = withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                        ?: throw IllegalStateException("File JSON tidak bisa dibaca.")
                }
                val converted = withContext(Dispatchers.Default) {
                    AlightMotionConverter.injectIntoCapCutJson(rawJson, xml, switchBakeJj.isChecked)
                }
                val outDir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                    "AM2CapCut"
                ).apply { mkdirs() }
                val outFile = File(outDir, "${xml.title}_draft_content.json")
                withContext(Dispatchers.IO) { outFile.writeText(converted) }
                log("BERHASIL! File tersimpan di Download/AM2CapCut/${outFile.name}")
            } catch (t: Throwable) {
                log("Gagal: ${t.message}")
            }
        }
    }

    private fun log(message: String) {
        tvLog.text = message
    }
}
