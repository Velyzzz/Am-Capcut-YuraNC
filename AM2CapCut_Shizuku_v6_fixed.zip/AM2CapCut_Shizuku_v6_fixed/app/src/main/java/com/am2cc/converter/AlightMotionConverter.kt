package com.am2cc.converter

import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.InputStream
import java.util.UUID
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

object AlightMotionConverter {

    data class KeyframePoint(
        val timeRatio: Float,
        val value: Float
    )

    data class ClipData(
        val label: String,
        val startMs: Long,
        val durationMs: Long,
        val scaleKeys: List<KeyframePoint>,
        val rotationKeys: List<KeyframePoint>,
        val posXKeys: List<KeyframePoint>,
        val posYKeys: List<KeyframePoint>,
        val hasOscillateOrSwing: Boolean,
        val oscFreq: Float,
        val oscMag: Float,
        val oscAngle: Float,
        val swingFreq: Float,
        val swingA1: Float,
        val swingA2: Float
    )

    data class ParsedXml(
        val title: String,
        val width: Int,
        val height: Int,
        val fps: Int,
        val clips: List<ClipData>,
        val totalJjEffects: Int
    )

    fun parseXml(inputStream: InputStream): ParsedXml {
        val factory = XmlPullParserFactory.newInstance()
        val parser = factory.newPullParser()
        parser.setInput(inputStream, "UTF-8")

        var title = "Preset_AM"
        var width = 1080
        var height = 1920
        var fps = 30
        val clips = mutableListOf<ClipData>()
        var totalEffects = 0

        var inMedia = false
        var clipLabel = ""
        var startTime = 0L
        var endTime = 0L

        var currentProp = ""
        var currentEffectId = ""
        val scaleKeys = mutableListOf<KeyframePoint>()
        val rotKeys = mutableListOf<KeyframePoint>()
        val posXKeys = mutableListOf<KeyframePoint>()
        val posYKeys = mutableListOf<KeyframePoint>()

        var hasOsc = false
        var oscFreq = 2.0f
        var oscMag = 25.0f
        var oscAngle = 90.0f
        var swingFreq = 2.0f
        var swingA1 = -8.0f
        var swingA2 = 8.0f

        var eventType = parser.eventType
        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    when (parser.name) {
                        "scene" -> {
                            title = parser.getAttributeValue(null, "title") ?: title
                            width = parser.getAttributeValue(null, "width")?.toIntOrNull() ?: 1080
                            height = parser.getAttributeValue(null, "height")?.toIntOrNull() ?: 1920
                            fps = parser.getAttributeValue(null, "fps")?.toIntOrNull() ?: 30
                        }
                        "media", "shape" -> {
                            val fillType = parser.getAttributeValue(null, "fillType") ?: ""
                            if (parser.name == "media" || fillType == "media") {
                                inMedia = true
                                clipLabel = parser.getAttributeValue(null, "label") ?: "Clip_${clips.size + 1}"
                                startTime = parser.getAttributeValue(null, "startTime")?.toLongOrNull() ?: 0L
                                endTime = parser.getAttributeValue(null, "endTime")?.toLongOrNull() ?: (startTime + 500L)
                                scaleKeys.clear()
                                rotKeys.clear()
                                posXKeys.clear()
                                posYKeys.clear()
                                hasOsc = false
                                oscFreq = 2.0f
                                oscMag = 25.0f
                                oscAngle = 90.0f
                                swingFreq = 2.0f
                                swingA1 = -8.0f
                                swingA2 = 8.0f
                            }
                        }
                        "property" -> {
                            if (inMedia) {
                                currentProp = parser.getAttributeValue(null, "name") ?: ""
                                val staticVal = parser.getAttributeValue(null, "value")
                                if (staticVal != null) {
                                    applyPropertyValue(
                                        currentProp, 0f, staticVal,
                                        width, height, scaleKeys, rotKeys, posXKeys, posYKeys
                                    )
                                    if (currentEffectId.contains("oscillate")) {
                                        when (currentProp) {
                                            "freq" -> oscFreq = staticVal.toFloatOrNull() ?: oscFreq
                                            "mag" -> oscMag = staticVal.toFloatOrNull() ?: oscMag
                                            "angle" -> oscAngle = staticVal.toFloatOrNull() ?: oscAngle
                                        }
                                    } else if (currentEffectId.contains("swing")) {
                                        when (currentProp) {
                                            "freq" -> swingFreq = staticVal.toFloatOrNull() ?: swingFreq
                                            "a1" -> swingA1 = staticVal.toFloatOrNull() ?: swingA1
                                            "a2" -> swingA2 = staticVal.toFloatOrNull() ?: swingA2
                                        }
                                    }
                                }
                            }
                        }
                        "kf" -> {
                            if (inMedia) {
                                val t = parser.getAttributeValue(null, "t")?.toFloatOrNull() ?: 0f
                                val v = parser.getAttributeValue(null, "v") ?: ""
                                applyPropertyValue(
                                    currentProp, t, v,
                                    width, height, scaleKeys, rotKeys, posXKeys, posYKeys
                                )
                            }
                        }
                        "effect" -> {
                            if (inMedia) {
                                totalEffects++
                                currentEffectId = parser.getAttributeValue(null, "id") ?: ""
                                if (currentEffectId.contains("oscillate") || currentEffectId.contains("swing")) {
                                    hasOsc = true
                                }
                            }
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    when (parser.name) {
                        "effect" -> currentEffectId = ""
                        "property" -> currentProp = ""
                        "media", "shape" -> {
                            if (inMedia) {
                                val dur = (endTime - startTime).coerceAtLeast(60L)
                                clips.add(
                                    ClipData(
                                        label = clipLabel,
                                        startMs = startTime,
                                        durationMs = dur,
                                        scaleKeys = scaleKeys.toList(),
                                        rotationKeys = rotKeys.toList(),
                                        posXKeys = posXKeys.toList(),
                                        posYKeys = posYKeys.toList(),
                                        hasOscillateOrSwing = hasOsc,
                                        oscFreq = oscFreq,
                                        oscMag = oscMag,
                                        oscAngle = oscAngle,
                                        swingFreq = swingFreq,
                                        swingA1 = swingA1,
                                        swingA2 = swingA2
                                    )
                                )
                                inMedia = false
                            }
                        }
                    }
                }
            }
            eventType = parser.next()
        }

        val sortedClips = clips.sortedBy { it.startMs }
        return ParsedXml(
            title = title,
            width = width,
            height = height,
            fps = fps,
            clips = sortedClips,
            totalJjEffects = totalEffects
        )
    }

    private fun applyPropertyValue(
        prop: String,
        t: Float,
        rawVal: String,
        sceneW: Int,
        sceneH: Int,
        scaleKeys: MutableList<KeyframePoint>,
        rotKeys: MutableList<KeyframePoint>,
        posXKeys: MutableList<KeyframePoint>,
        posYKeys: MutableList<KeyframePoint>
    ) {
        val parts = rawVal.split(",").mapNotNull { it.trim().toFloatOrNull() }
        if (parts.isEmpty()) return

        when (prop) {
            "scale" -> {
                scaleKeys.add(KeyframePoint(t.coerceIn(0f, 1f), parts[0]))
            }
            "rotation" -> {
                rotKeys.add(KeyframePoint(t.coerceIn(0f, 1f), parts[0]))
            }
            "location", "pos" -> {
                val normX = ((parts[0] - (sceneW / 2f)) / (sceneW / 2f)).coerceIn(-2f, 2f)
                val normY = if (parts.size > 1) {
                    ((parts[1] - (sceneH / 2f)) / (sceneH / 2f)).coerceIn(-2f, 2f)
                } else 0f
                posXKeys.add(KeyframePoint(t.coerceIn(0f, 1f), normX))
                posYKeys.add(KeyframePoint(t.coerceIn(0f, 1f), normY))
            }
        }
    }

    fun injectIntoCapCutJson(
        rawDraftJson: String,
        parsedXml: ParsedXml,
        bakeOscillateAndSwing: Boolean
    ): String {
        val trimmed = rawDraftJson.trimStart('\uFEFF', '\u0000', ' ', '\n', '\r', '\t')
        if (!trimmed.startsWith("{")) {
            throw IllegalStateException("File draft_content.json ini terenkripsi (versi CapCut terlalu baru). Gunakan CapCut v12.6.0 atau v12.8.0.")
        }

        val root = JSONObject(trimmed)
        val materials = root.optJSONObject("materials")
            ?: throw IllegalStateException("Struktur JSON CapCut tidak valid (materials kosong).")

        val videos = materials.optJSONArray("videos") ?: JSONArray()
        if (videos.length() == 0) {
            throw IllegalStateException("Draft CapCut belum memiliki foto/video. Masukkan minimal 1–3 foto dan 1 lagu terlebih dahulu.")
        }

        val sourceMaterials = mutableListOf<JSONObject>()
        for (i in 0 until videos.length()) {
            sourceMaterials.add(videos.getJSONObject(i))
        }

        val newVideos = JSONArray()
        val newCanvases = JSONArray()
        val newSpeeds = JSONArray()
        val videoSegments = JSONArray()
        val allKeyframes = root.optJSONArray("keyframes") ?: JSONArray()

        val clipsToBuild = if (parsedXml.clips.isNotEmpty()) {
            parsedXml.clips
        } else {
            listOf(
                ClipData("Clip_1", 0L, 3000L, emptyList(), emptyList(), emptyList(), emptyList(), false, 2f, 20f, 90f, 2f, -5f, 5f)
            )
        }

        var timelineCursorUs = 0L

        clipsToBuild.forEachIndexed { idx, clip ->
            val srcMat = sourceMaterials[idx % sourceMaterials.size]
            val durUs = (clip.durationMs * 1000L).coerceAtLeast(66666L)
            val startUs = if (clip.startMs > 0L) clip.startMs * 1000L else timelineCursorUs

            val matId = UUID.randomUUID().toString().uppercase()
            val canvasId = UUID.randomUUID().toString().uppercase()
            val speedId = UUID.randomUUID().toString().uppercase()
            val segId = UUID.randomUUID().toString().uppercase()

            val clonedMat = JSONObject(srcMat.toString()).apply {
                put("id", matId)
                put("duration", durUs)
            }
            newVideos.put(clonedMat)

            newCanvases.put(JSONObject().apply {
                put("id", canvasId)
                put("type", "canvas_color")
                put("color", "")
                put("blur", 0.0)
            })

            newSpeeds.put(JSONObject().apply {
                put("id", speedId)
                put("type", "speed")
                put("speed", 1.0)
                put("mode", 0)
            })

            val kfRefIds = JSONArray()
            val kfList = buildCapCutKeyframesForClip(clip, durUs, parsedXml, bakeOscillateAndSwing)
            for (kfObj in kfList) {
                allKeyframes.put(kfObj)
                kfRefIds.put(kfObj.getString("id"))
            }

            val baseScale = clip.scaleKeys.firstOrNull()?.value?.toDouble() ?: 1.0
            val baseRot = clip.rotationKeys.firstOrNull()?.value?.toDouble() ?: 0.0
            val baseX = clip.posXKeys.firstOrNull()?.value?.toDouble() ?: 0.0
            val baseY = clip.posYKeys.firstOrNull()?.value?.toDouble() ?: 0.0

            val segment = JSONObject().apply {
                put("id", segId)
                put("material_id", matId)
                put("target_timerange", JSONObject().apply {
                    put("start", startUs)
                    put("duration", durUs)
                })
                put("source_timerange", JSONObject().apply {
                    put("start", 0L)
                    put("duration", durUs)
                })
                put("extra_material_refs", JSONArray().apply {
                    put(speedId)
                    put(canvasId)
                })
                put("common_keyframes", kfRefIds)
                put("clip", JSONObject().apply {
                    put("alpha", 1.0)
                    put("flip", JSONObject().apply {
                        put("horizontal", false)
                        put("vertical", false)
                    })
                    put("rotation", baseRot)
                    put("scale", JSONObject().apply {
                        put("x", baseScale)
                        put("y", baseScale)
                    })
                    put("transform", JSONObject().apply {
                        put("x", baseX)
                        put("y", baseY)
                    })
                })
                put("volume", 1.0)
                put("visible", true)
                put("speed", 1.0)
            }

            videoSegments.put(segment)
            timelineCursorUs = startUs + durUs
        }

        materials.put("videos", newVideos)
        materials.put("canvases", newCanvases)
        materials.put("speeds", newSpeeds)
        root.put("keyframes", allKeyframes)
        root.put("duration", timelineCursorUs)

        val tracks = root.optJSONArray("tracks") ?: JSONArray()
        var replacedVideoTrack = false
        for (i in 0 until tracks.length()) {
            val tr = tracks.getJSONObject(i)
            if (tr.optString("type") == "video" && !replacedVideoTrack) {
                tr.put("segments", videoSegments)
                replacedVideoTrack = true
            }
        }
        if (!replacedVideoTrack) {
            tracks.put(JSONObject().apply {
                put("id", UUID.randomUUID().toString().uppercase())
                put("type", "video")
                put("attribute", 0)
                put("segments", videoSegments)
            })
        }
        root.put("tracks", tracks)

        return root.toString(2)
    }

    private fun buildCapCutKeyframesForClip(
        clip: ClipData,
        durUs: Long,
        parsedXml: ParsedXml,
        bakeOscSwing: Boolean
    ): List<JSONObject> {
        val result = mutableListOf<JSONObject>()
        val samples = if (bakeOscSwing && clip.hasOscillateOrSwing) 8 else 4
        val durSec = durUs / 1_000_000.0

        val scaleKfList = JSONArray()
        val rotKfList = JSONArray()
        val posXKfList = JSONArray()
        val posYKfList = JSONArray()

        for (step in 0..samples) {
            val ratio = step.toFloat() / samples.toFloat()
            val timeOffsetUs = (durUs * ratio).toLong()
            val tSec = durSec * ratio
            val decay = (1.0 - ratio * 0.65)

            var sVal = interpolate(clip.scaleKeys, ratio, 1.0f).toDouble()
            var rVal = interpolate(clip.rotationKeys, ratio, 0.0f).toDouble()
            var xVal = interpolate(clip.posXKeys, ratio, 0.0f).toDouble()
            var yVal = interpolate(clip.posYKeys, ratio, 0.0f).toDouble()

            if (bakeOscSwing && clip.hasOscillateOrSwing) {
                val rad = clip.oscAngle * PI / 180.0
                val wave = sin(2.0 * PI * clip.oscFreq * tSec) * decay
                val normMag = (clip.oscMag / (parsedXml.height / 2.0)) * wave
                xVal += cos(rad) * normMag
                yVal += sin(rad) * normMag

                val swingWave = sin(2.0 * PI * clip.swingFreq * tSec) * decay
                val midAngle = (clip.swingA1 + clip.swingA2) / 2.0
                val ampAngle = (clip.swingA2 - clip.swingA1) / 2.0
                rVal += midAngle * decay + ampAngle * swingWave
                sVal += 0.04 * cos(2.0 * PI * clip.oscFreq * tSec) * decay
            }

            scaleKfList.put(makeKfNode(timeOffsetUs, sVal))
            rotKfList.put(makeKfNode(timeOffsetUs, rVal))
            posXKfList.put(makeKfNode(timeOffsetUs, xVal))
            posYKfList.put(makeKfNode(timeOffsetUs, yVal))
        }

        result.add(wrapTrackKeyframe("KFTypeScaleX", scaleKfList))
        result.add(wrapTrackKeyframe("KFTypeScaleY", scaleKfList))
        result.add(wrapTrackKeyframe("KFTypeRotation", rotKfList))
        result.add(wrapTrackKeyframe("KFTypePositionX", posXKfList))
        result.add(wrapTrackKeyframe("KFTypePositionY", posYKfList))

        return result
    }

    private fun interpolate(keys: List<KeyframePoint>, ratio: Float, defaultVal: Float): Float {
        if (keys.isEmpty()) return defaultVal
        val sorted = keys.sortedBy { it.timeRatio }
        if (ratio <= sorted.first().timeRatio) return sorted.first().value
        if (ratio >= sorted.last().timeRatio) return sorted.last().value

        for (i in 0 until sorted.size - 1) {
            val a = sorted[i]
            val b = sorted[i + 1]
            if (ratio in a.timeRatio..b.timeRatio) {
                val span = (b.timeRatio - a.timeRatio).coerceAtLeast(0.0001f)
                val f = (ratio - a.timeRatio) / span
                return a.value + (b.value - a.value) * f
            }
        }
        return sorted.last().value
    }

    private fun makeKfNode(timeOffsetUs: Long, value: Double): JSONObject {
        return JSONObject().apply {
            put("id", UUID.randomUUID().toString().uppercase())
            put("time_offset", timeOffsetUs)
            put("values", JSONArray().apply { put(value) })
            put("curveType", "Line")
            put("graphID", "")
        }
    }

    private fun wrapTrackKeyframe(propertyType: String, kfList: JSONArray): JSONObject {
        return JSONObject().apply {
            put("id", UUID.randomUUID().toString().uppercase())
            put("property_type", propertyType)
            put("keyframe_list", kfList)
        }
    }
}
