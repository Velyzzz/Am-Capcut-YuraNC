package com.am2cc.converter

import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.InputStream
import java.util.UUID
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

object AlightMotionConverter {
    data class KeyframePoint(val timeRatio: Float, val value: Float)
    data class ClipData(
        val label: String, val startMs: Long, val durationMs: Long,
        val scaleKeys: List<KeyframePoint>, val rotationKeys: List<KeyframePoint>,
        val posXKeys: List<KeyframePoint>, val posYKeys: List<KeyframePoint>,
        val hasOscillateOrSwing: Boolean, val oscFreq: Float, val oscMag: Float,
        val oscAngle: Float, val swingFreq: Float, val swingA1: Float, val swingA2: Float
    )
    data class ParsedXml(
        val title: String, val width: Int, val height: Int,
        val fps: Int, val clips: List<ClipData>, val totalJjEffects: Int
    )

    fun parseXml(inputStream: InputStream): ParsedXml {
        val factory = XmlPullParserFactory.newInstance()
        val parser = factory.newPullParser()
        parser.setInput(inputStream, "UTF-8")

        var title = "Preset_AM"
        var width = 1080
        var height = 1920
        var fps = 30
        val clips = mutableListOf<ClipData>()
        var totalEffects = 0

        var inMedia = false
        var clipLabel = ""
        var startTime = 0L
        var endTime = 0L
        var currentProp = ""
        var currentEffectId = ""
        val scaleKeys = mutableListOf<KeyframePoint>()
        val rotKeys = mutableListOf<KeyframePoint>()
        val posXKeys = mutableListOf<KeyframePoint>()
        val posYKeys = mutableListOf<KeyframePoint>()

        var hasOsc = false
        var oscFreq = 2.0f
        var oscMag = 25.0f
        var oscAngle = 90.0f
        var swingFreq = 2.0f
        var swingA1 = -8.0f
        var swingA2 = 8.0f

        var eventType = parser.eventType
        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    when (parser.name) {
                        "scene" -> {
                            title = parser.getAttributeValue(null, "title") ?: title
                            width = parser.getAttributeValue(null, "width")?.toIntOrNull() ?: 1080
                            height = parser.getAttributeValue(null, "height")?.toIntOrNull() ?: 1920
                            fps = parser.getAttributeValue(null, "fps")?.toIntOrNull() ?: 30
                        }
                        "media", "shape" -> {
                            val fillType = parser.getAttributeValue(null, "fillType") ?: ""
                            if (parser.name == "media" || fillType == "media") {
                                inMedia = true
                                clipLabel = parser.getAttributeValue(null, "label") ?: "Clip_${clips.size + 1}"
                                startTime = parser.getAttributeValue(null, "startTime")?.toLongOrNull() ?: 0L
                                endTime = parser.getAttributeValue(null, "endTime")?.toLongOrNull() ?: (startTime + 500L)
                                scaleKeys.clear(); rotKeys.clear(); posXKeys.clear(); posYKeys.clear()
                                hasOsc = false
                            }
                        }
                        "property" -> {
                            if (inMedia) {
                                currentProp = parser.getAttributeValue(null, "name") ?: ""
                                val staticVal = parser.getAttributeValue(null, "value")
                                if (staticVal != null) {
                                    applyProp(currentProp, 0f, staticVal, width, height, scaleKeys, rotKeys, posXKeys, posYKeys)
                                }
                            }
                        }
                        "kf" -> {
                            if (inMedia) {
                                val t = parser.getAttributeValue(null, "t")?.toFloatOrNull() ?: 0f
                                val v = parser.getAttributeValue(null, "v") ?: ""
                                applyProp(currentProp, t, v, width, height, scaleKeys, rotKeys, posXKeys, posYKeys)
                            }
                        }
                        "effect" -> {
                            if (inMedia) {
                                totalEffects++
                                currentEffectId = parser.getAttributeValue(null, "id") ?: ""
                                if (currentEffectId.contains("oscillate") || currentEffectId.contains("swing")) {
                                    hasOsc = true
                                }
                            }
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    when (parser.name) {
                        "media", "shape" -> {
                            if (inMedia) {
                                val dur = (endTime - startTime).coerceAtLeast(60L)
                                clips.add(ClipData(clipLabel, startTime, dur, scaleKeys.toList(), rotKeys.toList(), posXKeys.toList(), posYKeys.toList(), hasOsc, oscFreq, oscMag, oscAngle, swingFreq, swingA1, swingA2))
                                inMedia = false
                            }
                        }
                    }
                }
            }
            eventType = parser.next()
        }
        return ParsedXml(title, width, height, fps, clips.sortedBy { it.startMs }, totalEffects)
    }

    private fun applyProp(prop: String, t: Float, rawVal: String, w: Int, h: Int, sk: MutableList<KeyframePoint>, rk: MutableList<KeyframePoint>, xk: MutableList<KeyframePoint>, yk: MutableList<KeyframePoint>) {
        val parts = rawVal.split(",").mapNotNull { it.trim().toFloatOrNull() }
        if (parts.isEmpty()) return
        when (prop) {
            "scale" -> sk.add(KeyframePoint(t.coerceIn(0f, 1f), parts[0]))
            "rotation" -> rk.add(KeyframePoint(t.coerceIn(0f, 1f), parts[0]))
            "location", "pos" -> {
                val nx = ((parts[0] - (w / 2f)) / (w / 2f)).coerceIn(-2f, 2f)
                val ny = if (parts.size > 1) ((parts[1] - (h / 2f)) / (h / 2f)).coerceIn(-2f, 2f) else 0f
                xk.add(KeyframePoint(t.coerceIn(0f, 1f), nx))
                yk.add(KeyframePoint(t.coerceIn(0f, 1f), ny))
            }
        }
    }

    fun injectIntoCapCutJson(rawJson: String, parsed: ParsedXml, bake: Boolean): String {
        val root = JSONObject(rawJson.trimStart('\uFEFF', '\u0000', ' ', '\n', '\r', '\t'))
        val materials = root.optJSONObject("materials") ?: throw IllegalStateException("Materials kosong.")
        val videos = materials.optJSONArray("videos") ?: JSONArray()
        if (videos.length() == 0) throw IllegalStateException("Draft CapCut belum ada video/foto.")

        val srcMats = (0 until videos.length()).map { videos.getJSONObject(it) }
        val newVideos = JSONArray()
        val newCanvases = JSONArray()
        val newSpeeds = JSONArray()
        val segments = JSONArray()
        val allKf = root.optJSONArray("keyframes") ?: JSONArray()

        val clips = parsed.clips.ifEmpty { listOf(ClipData("Clip_1", 0L, 3000L, emptyList(), emptyList(), emptyList(), emptyList(), false, 2f, 20f, 90f, 2f, -5f, 5f)) }
        var cursor = 0L

        clips.forEachIndexed { i, clip ->
            val mat = srcMats[i % srcMats.size]
            val dur = (clip.durationMs * 1000L).coerceAtLeast(66666L)
            val start = if (clip.startMs > 0L) clip.startMs * 1000L else cursor

            val mId = UUID.randomUUID().toString().uppercase()
            val cId = UUID.randomUUID().toString().uppercase()
            val sId = UUID.randomUUID().toString().uppercase()
            val segId = UUID.randomUUID().toString().uppercase()

            newVideos.put(JSONObject(mat.toString()).put("id", mId).put("duration", dur))
            newCanvases.put(JSONObject().put("id", cId).put("type", "canvas_color").put("color", "").put("blur", 0.0))
            newSpeeds.put(JSONObject().put("id", sId).put("type", "speed").put("speed", 1.0).put("mode", 0))

            val kfIds = JSONArray()
            for (kf in buildKf(clip, dur, parsed, bake)) {
                allKf.put(kf)
                kfIds.put(kf.getString("id"))
            }

            segments.put(JSONObject().apply {
                put("id", segId)
                put("material_id", mId)
                put("target_timerange", JSONObject().put("start", start).put("duration", dur))
                put("source_timerange", JSONObject().put("start", 0L).put("duration", dur))
                put("extra_material_refs", JSONArray().put(sId).put(cId))
                put("common_keyframes", kfIds)
                put("clip", JSONObject().apply {
                    put("alpha", 1.0)
                    put("flip", JSONObject().put("horizontal", false).put("vertical", false))
                    put("rotation", clip.rotationKeys.firstOrNull()?.value?.toDouble() ?: 0.0)
                    put("scale", JSONObject().put("x", clip.scaleKeys.firstOrNull()?.value?.toDouble() ?: 1.0).put("y", clip.scaleKeys.firstOrNull()?.value?.toDouble() ?: 1.0))
                    put("transform", JSONObject().put("x", clip.posXKeys.firstOrNull()?.value?.toDouble() ?: 0.0).put("y", clip.posYKeys.firstOrNull()?.value?.toDouble() ?: 0.0))
                })
                put("volume", 1.0)
                put("visible", true)
                put("speed", 1.0)
            })
            cursor = start + dur
        }

        materials.put("videos", newVideos).put("canvases", newCanvases).put("speeds", newSpeeds)
        root.put("keyframes", allKf).put("duration", cursor)

        val tracks = root.optJSONArray("tracks") ?: JSONArray()
        var replaced = false
        for (i in 0 until tracks.length()) {
            val tr = tracks.getJSONObject(i)
            if (tr.optString("type") == "video" && !replaced) {
                tr.put("segments", segments)
                replaced = true
            }
        }
        if (!replaced) {
            tracks.put(JSONObject().put("id", UUID.randomUUID().toString().uppercase()).put("type", "video").put("attribute", 0).put("segments", segments))
        }
        root.put("tracks", tracks)
        return root.toString(2)
    }

    private fun buildKf(clip: ClipData, dur: Long, parsed: ParsedXml, bake: Boolean): List<JSONObject> {
        val list = mutableListOf<JSONObject>()
        val samples = if (bake && clip.hasOscillateOrSwing) 8 else 4
        val durSec = dur / 1_000_000.0

        val sk = JSONArray()
        val rk = JSONArray()
        val xk = JSONArray()
        val yk = JSONArray()

        for (s in 0..samples) {
            val ratio = s.toFloat() / samples.toFloat()
            val tUs = (dur * ratio).toLong()
            val tSec = durSec * ratio
            val decay = (1.0 - ratio * 0.65)

            var sc = interpolate(clip.scaleKeys, ratio, 1.0f).toDouble()
            var ro = interpolate(clip.rotationKeys, ratio, 0.0f).toDouble()
            var px = interpolate(clip.posXKeys, ratio, 0.0f).toDouble()
            var py = interpolate(clip.posYKeys, ratio, 0.0f).toDouble()

            if (bake && clip.hasOscillateOrSwing) {
                val rad = clip.oscAngle * PI / 180.0
                val wave = sin(2.0 * PI * clip.oscFreq * tSec) * decay
                val normMag = (clip.oscMag / (parsed.height / 2.0)) * wave
                px += cos(rad) * normMag
                py += sin(rad) * normMag
                val sw = sin(2.0 * PI * clip.swingFreq * tSec) * decay
                ro += ((clip.swingA1 + clip.swingA2) / 2.0) * decay + ((clip.swingA2 - clip.swingA1) / 2.0) * sw
            }

            sk.put(mkKf(tUs, sc))
            rk.put(mkKf(tUs, ro))
            xk.put(mkKf(tUs, px))
            yk.put(mkKf(tUs, py))
        }

        list.add(wrKf("KFTypeScaleX", sk))
        list.add(wrKf("KFTypeScaleY", sk))
        list.add(wrKf("KFTypeRotation", rk))
        list.add(wrKf("KFTypePositionX", xk))
        list.add(wrKf("KFTypePositionY", yk))
        return list
    }

    private fun interpolate(keys: List<KeyframePoint>, ratio: Float, defaultVal: Float): Float {
        if (keys.isEmpty()) return defaultVal
        val sorted = keys.sortedBy { it.timeRatio }
        if (ratio <= sorted.first().timeRatio) return sorted.first().value
        if (ratio >= sorted.last().timeRatio) return sorted.last().value
        for (i in 0 until sorted.size - 1) {
            val a = sorted[i]; val b = sorted[i + 1]
            if (ratio in a.timeRatio..b.timeRatio) {
                val f = (ratio - a.timeRatio) / (b.timeRatio - a.timeRatio).coerceAtLeast(0.0001f)
                return a.value + (b.value - a.value) * f
            }
        }
        return sorted.last().value
    }

    private fun mkKf(t: Long, v: Double) = JSONObject().put("id", UUID.randomUUID().toString().uppercase()).put("time_offset", t).put("values", JSONArray().put(v)).put("curveType", "Line").put("graphID", "")
    private fun wrKf(type: String, list: JSONArray) = JSONObject().put("id", UUID.randomUUID().toString().uppercase()).put("property_type", type).put("keyframe_list", list)
}
