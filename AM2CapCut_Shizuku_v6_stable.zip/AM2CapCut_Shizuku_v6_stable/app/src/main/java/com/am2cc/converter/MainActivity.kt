package com.am2cc.converter

import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var tvStatus: TextView
    private lateinit var btnShizuku: Button
    private lateinit var tvXml: TextView
    private lateinit var btnXml: Button
    private lateinit var btnRefresh: TextView
    private lateinit var spinner: Spinner
    private lateinit var switchBake: SwitchCompat
    private lateinit var btnInject: Button
    private lateinit var btnBackup: Button
    private lateinit var tvLog: TextView

    private var parsedXml: AlightMotionConverter.ParsedXml? = null
    private val draftList = mutableListOf<String>()

    private val xmlLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) loadXmlFile(uri)
    }
    private val jsonLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) processBackup(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        btnShizuku = findViewById(R.id.btnShizuku)
        tvXml = findViewById(R.id.tvXml)
        btnXml = findViewById(R.id.btnXml)
        btnRefresh = findViewById(R.id.btnRefresh)
        spinner = findViewById(R.id.spinner)
        switchBake = findViewById(R.id.switchBake)
        btnInject = findViewById(R.id.btnInject)
        btnBackup = findViewById(R.id.btnBackup)
        tvLog = findViewById(R.id.tvLog)

        btnShizuku.setOnClickListener { reqShizuku() }
        btnXml.setOnClickListener { xmlLauncher.launch(arrayOf("*/*")) }
        btnRefresh.setOnClickListener { loadDrafts() }
        btnInject.setOnClickListener { injectXml() }
        btnBackup.setOnClickListener {
            if (parsedXml == null) { log("Pilih file XML terlebih dahulu!"); return@setOnClickListener }
            jsonLauncher.launch(arrayOf("application/json", "*/*"))
        }

        checkShizukuStatus()
    }

    private fun reqShizuku() {
        try {
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) checkShizukuStatus()
            else Shizuku.requestPermission(1001)
        } catch (e: Throwable) {
            tvStatus.text = "Error Shizuku: ${e.message}"
        }
    }

    private fun checkShizukuStatus() {
        try {
            if (!ShizukuShell.isReady()) {
                tvStatus.text = "Status: Shizuku belum aktif / belum dibuka."
                return
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                tvStatus.text = "Status: Shizuku aktif, perlu izin akses."
                return
            }
            tvStatus.text = "Status: Shizuku Terhubung (aShell Aktif)"
            loadDrafts()
        } catch (e: Throwable) {
            tvStatus.text = "Status Error: ${e.message}"
        }
    }

    private fun loadDrafts() {
        lifecycleScope.launch {
            log("Memindai proyek CapCut...")
            val drafts = withContext(Dispatchers.IO) { ShizukuShell.listDraftProjects() }
            draftList.clear()
            draftList.addAll(drafts)
            if (drafts.isNotEmpty()) {
                spinner.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, draftList)
                log("Ditemukan ${drafts.size} draft CapCut.")
            } else {
                log("Draft CapCut kosong atau folder tidak ditemukan.")
            }
        }
    }

    private fun loadXmlFile(uri: Uri) {
        lifecycleScope.launch {
            try {
                val parsed = withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)?.use { AlightMotionConverter.parseXml(it) }
                }
                if (parsed != null) {
                    parsedXml = parsed
                    tvXml.text = "XML: ${parsed.title} (${parsed.clips.size} klip)"
                    log("Preset XML berhasil dimuat.")
                }
            } catch (e: Throwable) {
                log("Gagal baca XML: ${e.message}")
            }
        }
    }

    private fun injectXml() {
        val xml = parsedXml ?: run { log("Pilih preset XML terlebih dahulu!"); return }
        val folder = spinner.selectedItem?.toString() ?: run { log("Pilih draft CapCut terlebih dahulu!"); return }

        lifecycleScope.launch {
            log("1/3 Menarik file draft dari CapCut...")
            val cacheIn = File(cacheDir, "draft_in.json")
            val pull = withContext(Dispatchers.IO) { ShizukuShell.pullDraftToCache(folder, cacheIn) }
            if (pull.code != 0) { log("Gagal menarik draft: ${pull.stderr}"); return@launch }

            log("2/3 Mengonversi preset XML ke format CapCut...")
            val raw = withContext(Dispatchers.IO) { cacheIn.readText() }
            val converted = withContext(Dispatchers.Default) {
                AlightMotionConverter.injectIntoCapCutJson(raw, xml, switchBake.isChecked)
            }
            val cacheOut = File(cacheDir, "draft_out.json")
            withContext(Dispatchers.IO) { cacheOut.writeText(converted) }

            log("3/3 Menimpa draft & merestart CapCut...")
            val push = withContext(Dispatchers.IO) { ShizukuShell.pushDraftAndRestartCapCut(cacheOut, folder) }
            if (push.code == 0) {
                log("SUKSES! Silakan buka CapCut, proyek sudah berisi JJ.")
            } else {
                log("Gagal menimpa draft: ${push.stderr}")
            }
        }
    }

    private fun processBackup(uri: Uri) {
        val xml = parsedXml ?: return
        lifecycleScope.launch {
            try {
                val raw = withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                }
                val converted = withContext(Dispatchers.Default) {
                    AlightMotionConverter.injectIntoCapCutJson(raw, xml, switchBake.isChecked)
                }
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "AM2CapCut").apply { mkdirs() }
                val file = File(dir, "${xml.title}_draft.json")
                withContext(Dispatchers.IO) { file.writeText(converted) }
                log("Berhasil! Tersimpan di Download/AM2CapCut/")
            } catch (e: Throwable) {
                log("Gagal proses backup: ${e.message}")
            }
        }
    }

    private fun log(msg: String) { tvLog.text = msg }
}
