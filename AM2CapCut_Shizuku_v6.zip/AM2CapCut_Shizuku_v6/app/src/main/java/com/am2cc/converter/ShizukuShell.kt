package com.am2cc.converter

import rikka.shizuku.Shizuku
import java.io.File

object ShizukuShell {
    private val CANDIDATE_DIRS = listOf(
        "/sdcard/Android/data/com.lemon.lvoverseas/files/New Project",
        "/storage/emulated/0/Android/data/com.lemon.lvoverseas/files/New Project",
        "/sdcard/Android/data/com.vega.edit/files/New Project"
    )

    data class CmdResult(
        val code: Int,
        val stdout: String,
        val stderr: String
    )

    fun isReady(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (_: Throwable) {
            false
        }
    }

    fun exec(command: String): CmdResult {
        return try {
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            ).apply { isAccessible = true }

            val process = method.invoke(
                null,
                arrayOf("sh", "-c", command),
                null,
                null
            ) as Process

            val out = process.inputStream.bufferedReader().readText().trim()
            val err = process.errorStream.bufferedReader().readText().trim()
            val exit = process.waitFor()
            CmdResult(exit, out, err)
        } catch (t: Throwable) {
            CmdResult(-1, "", t.message ?: "Gagal menjalankan perintah shell Shizuku")
        }
    }

    fun resolveCapCutBaseDir(): String {
        for (dir in CANDIDATE_DIRS) {
            val res = exec("[ -d "$dir" ] && echo OK")
            if (res.stdout == "OK") return dir
        }
        return CANDIDATE_DIRS.first()
    }

    fun listDraftProjects(): Pair<String, List<String>> {
        val baseDir = resolveCapCutBaseDir()
        val res = exec("ls -1t "$baseDir" 2>&1")
        if (res.code != 0 || res.stdout.isBlank()) {
            return Pair(res.stdout.ifBlank { res.stderr }, emptyList())
        }
        val folders = res.stdout.lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith(".") && !it.contains("No such file") && !it.contains("Permission denied") }
        return Pair("OK", folders)
    }

    fun pullDraftToCache(projectFolder: String, targetCacheFile: File): CmdResult {
        val baseDir = resolveCapCutBaseDir()
        val srcContent = "$baseDir/$projectFolder/draft_content.json"
        val srcInfo = "$baseDir/$projectFolder/draft_info.json"
        val dst = targetCacheFile.absolutePath

        val script = """
            rm -f "$dst"
            if [ -s "$srcContent" ]; then
                cp "$srcContent" "$dst"
            elif [ -s "$srcInfo" ]; then
                cp "$srcInfo" "$dst"
            else
                echo "FILE_KOSONG" >&2
                exit 2
            fi
            chmod 666 "$dst"
        """.trimIndent()

        return exec(script)
    }

    fun pushDraftAndRestartCapCut(convertedFile: File, projectFolder: String): CmdResult {
        val baseDir = resolveCapCutBaseDir()
        val dstContent = "$baseDir/$projectFolder/draft_content.json"
        val dstInfo = "$baseDir/$projectFolder/draft_info.json"
        val src = convertedFile.absolutePath

        val script = """
            cp "$src" "$dstContent"
            chmod 666 "$dstContent"
            if [ -f "$dstInfo" ]; then
                cp "$src" "$dstInfo"
                chmod 666 "$dstInfo"
            fi
            am force-stop com.lemon.lvoverseas
            am force-stop com.vega.edit
        """.trimIndent()

        return exec(script)
    }
}
